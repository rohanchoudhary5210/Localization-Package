using UnityEngine;
using UnityEditor;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;
using System.Text.RegularExpressions;

public class FillLocalizationKeysFromText
{
    private static readonly string[] PossibleKeyFieldNames =
    {
        "localizationKey",
        "key",
        "localizationID",
        "localizationId",
        "entryKey"
    };

    private static int numericKeyCounter = 1;

    [MenuItem("Tools/Localization/Fill Localization Keys From Text")]
    public static void FillKeys()
    {
        Scene scene = SceneManager.GetActiveScene();
        GameObject[] roots = scene.GetRootGameObjects();

        int filledCount = 0;
        numericKeyCounter = 1;

        foreach (GameObject root in roots)
        {
            // Legacy Text
            foreach (Text text in root.GetComponentsInChildren<Text>(true))
            {
                var loc = text.GetComponent<LocalizedLegacyText>();
                if (loc != null)
                    filledCount += TryAssignKey(loc, text.text);
            }

            // TMP Text
            foreach (TextMeshProUGUI tmp in root.GetComponentsInChildren<TextMeshProUGUI>(true))
            {
                var loc = tmp.GetComponent<LocalizedTMPText>();
                if (loc != null)
                    filledCount += TryAssignKey(loc, tmp.text);
            }
        }

        Debug.Log($"Filled {filledCount} localization keys in scene '{scene.name}'.");
    }

    private static int TryAssignKey(Object localizationComponent, string sourceText)
    {
        if (string.IsNullOrWhiteSpace(sourceText))
            return 0;

        sourceText = Regex.Replace(sourceText, "<.*?>", "").Trim();

        // Rule 1: skip if text is only a number
        if (IsOnlyNumber(sourceText))
            return 0;

        SerializedObject so = new SerializedObject(localizationComponent);

        foreach (string fieldName in PossibleKeyFieldNames)
        {
            SerializedProperty prop = so.FindProperty(fieldName);
            if (prop != null && prop.propertyType == SerializedPropertyType.String)
            {
                if (!string.IsNullOrEmpty(prop.stringValue))
                    return 0;

                // Rule 2: multi-word text → numeric keys
                if (IsMultiWord(sourceText))
                {
                    prop.stringValue = numericKeyCounter.ToString();
                    numericKeyCounter++;
                }
                else
                {
                    // Rule 3: single word → normal key
                    prop.stringValue = GenerateKey(sourceText);
                }

                so.ApplyModifiedProperties();
                EditorUtility.SetDirty(localizationComponent);
                return 1;
            }
        }

        return 0;
    }

    private static bool IsOnlyNumber(string text)
    {
        return Regex.IsMatch(text, @"^\d+$");
    }

    private static bool IsMultiWord(string text)
    {
        return text.Split(' ').Length > 1;
    }

    private static string GenerateKey(string source)
    {
        source = Regex.Replace(source, @"[^a-zA-Z0-9]+", "_");
        source = source.Trim('_');
        return source.ToUpperInvariant();
    }
}
