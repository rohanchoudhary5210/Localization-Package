using UnityEngine;
using UnityEditor;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Text;

public class ExportSceneTextsList
{
    private const string OutputFolder = "Assets/Localization/Data";
    private const string OutputFileName = "SceneTextsForGPT.txt";

    private const string PromptHeader =
@"Generate ONLY valid JSON for a game localization file.

Constraints:
- No markdown
- No comments
- No explanations
- No trailing commas
- Preserve key order
- Use uppercase keys

Structure:
{
  ""KEY"": {
    ""en"": ""English"",
    ""pt-BR"": ""Portuguese (Brazil)"",
    ""ru"": ""Russian"",
    ""sp"": ""Spanish"",
    ""fr"": ""French"",
    ""ar"": ""Arabic""
  }
}

Entries:
";

    private static int numericKeyCounter = 1;

    [MenuItem("Tools/Localization/Export Scene Texts (GPT Prompt)")]
    public static void ExportTexts()
    {
        Scene scene = SceneManager.GetActiveScene();
        GameObject[] roots = scene.GetRootGameObjects();

        HashSet<string> processedTexts = new HashSet<string>();
        List<string> outputLines = new List<string>();

        numericKeyCounter = 1;

        foreach (GameObject root in roots)
        {
            foreach (Text text in root.GetComponentsInChildren<Text>(true))
                TryAdd(processedTexts, outputLines, text.text);

            foreach (TextMeshProUGUI tmp in root.GetComponentsInChildren<TextMeshProUGUI>(true))
                TryAdd(processedTexts, outputLines, tmp.text);
        }

        if (!Directory.Exists(OutputFolder))
            Directory.CreateDirectory(OutputFolder);

        StringBuilder builder = new StringBuilder();
        builder.AppendLine(PromptHeader);

        foreach (string line in outputLines)
            builder.AppendLine(line);

        string fullPath = Path.Combine(OutputFolder, OutputFileName);
        File.WriteAllText(fullPath, builder.ToString());

        AssetDatabase.Refresh();

        Debug.Log($"Exported {outputLines.Count} localization entries to {fullPath}");
    }

    private static void TryAdd(HashSet<string> seen, List<string> output, string source)
    {
        if (string.IsNullOrWhiteSpace(source))
            return;

        source = Regex.Replace(source, "<.*?>", "").Trim();

        if (string.IsNullOrEmpty(source))
            return;

        // Skip number-only texts
        if (Regex.IsMatch(source, @"^\d+$"))
            return;

        // Avoid duplicates
        if (!seen.Add(source))
            return;

        string key;

        // Multi-word → numeric key
        if (source.Split(' ').Length > 1)
        {
            key = numericKeyCounter.ToString();
            numericKeyCounter++;
        }
        else
        {
            // Single-word → generated key
            key = GenerateKey(source);
        }

        output.Add($"{key} = {source}");
    }

    private static string GenerateKey(string source)
    {
        source = Regex.Replace(source, @"[^a-zA-Z0-9]+", "_");
        source = source.Trim('_');
        return source.ToUpperInvariant();
    }
}
