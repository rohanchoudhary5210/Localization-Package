using UnityEngine;
using UnityEditor;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class AddLocalizationToEntireScene
{
    [MenuItem("Tools/Localization/Add Localization To Entire Scene")]
    public static void AddLocalizationToScene()
    {
        Scene scene = SceneManager.GetActiveScene();
        GameObject[] rootObjects = scene.GetRootGameObjects();

        int addedCount = 0;

        foreach (GameObject root in rootObjects)
        {
            // Legacy UI Text
            Text[] legacyTexts = root.GetComponentsInChildren<Text>(true);
            foreach (Text text in legacyTexts)
            {
                if (text.GetComponent<LocalizedLegacyText>() == null)
                {
                    Undo.AddComponent<LocalizedLegacyText>(text.gameObject);
                    addedCount++;
                }
            }

            // TextMeshPro
            TextMeshProUGUI[] tmpTexts = root.GetComponentsInChildren<TextMeshProUGUI>(true);
            foreach (TextMeshProUGUI tmp in tmpTexts)
            {
                if (tmp.GetComponent<LocalizedTMPText>() == null)
                {
                    Undo.AddComponent<LocalizedTMPText>(tmp.gameObject);
                    addedCount++;
                }
            }
        }

        Debug.Log($"Localization added to {addedCount} text components in scene '{scene.name}'.");
    }
}
